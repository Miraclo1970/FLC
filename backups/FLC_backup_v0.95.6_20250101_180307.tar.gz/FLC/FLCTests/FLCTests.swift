//
//  FLCTests.swift
//  FLCTests
//
//  Created by Mirko van Velden on 13/12/2024.
//

import Testing
@testable import FLC

struct FLCTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
