import SwiftUI

struct AdminStuffView: View {
    var body: some View {
        ValidationRulesView()
    }
}

#Preview {
    AdminStuffView()
} 