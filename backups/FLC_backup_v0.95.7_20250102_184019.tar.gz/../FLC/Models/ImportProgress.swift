import Foundation

class ImportProgress: ObservableObject {
    enum DataType: String {
        case ad = "AD"
        case hr = "HR"
        case packageStatus = "Package Status"
        case testing = "Testing"
        case migration = "Migration"
        case combined = "Combined"
        case cluster = "Cluster"
    }
    
    @Published var isProcessing = false
    @Published var progressValue: Double = 0.0
    @Published var currentOperation = ""
    @Published var selectedDataType: DataType = .ad
    @Published var searchText: String = ""
    
    // AD Records
    @Published var validRecords: [ADData] = []
    @Published var invalidRecords: [String] = []
    @Published var duplicateRecords: [String] = []
    
    // HR Records
    @Published var validHRRecords: [HRData] = []
    @Published var invalidHRRecords: [String] = []
    @Published var duplicateHRRecords: [String] = []
    
    // Package Status Records
    @Published var validPackageRecords: [PackageStatusData] = []
    @Published var invalidPackageRecords: [String] = []
    @Published var duplicatePackageRecords: [String] = []
    
    // Test Records
    @Published var validTestRecords: [TestingData] = []
    @Published var invalidTestRecords: [String] = []
    @Published var duplicateTestRecords: [String] = []
    
    // Migration Records
    @Published var validMigrationRecords: [MigrationData] = []
    @Published var invalidMigrationRecords: [String] = []
    @Published var duplicateMigrationRecords: [String] = []
    
    // Cluster Records
    @Published var validClusterRecords: [ClusterData] = []
    @Published var invalidClusterRecords: [String] = []
    @Published var duplicateClusterRecords: [String] = []
    
    // MARK: - Filtered Results
    
    var filteredValidRecords: [ADData] {
        filterRecords(validRecords) { record in
            record.adGroup.localizedCaseInsensitiveContains(searchText) ||
            record.systemAccount.localizedCaseInsensitiveContains(searchText) ||
            record.applicationName.localizedCaseInsensitiveContains(searchText) ||
            record.applicationSuite.localizedCaseInsensitiveContains(searchText) ||
            record.otap.localizedCaseInsensitiveContains(searchText) ||
            record.critical.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    var filteredValidHRRecords: [HRData] {
        filterRecords(validHRRecords) { record in
            let systemAccountMatch = record.systemAccount.localizedCaseInsensitiveContains(searchText)
            let departmentMatch = record.department?.localizedCaseInsensitiveContains(searchText) ?? false
            let departmentSimpleMatch = record.departmentSimple?.localizedCaseInsensitiveContains(searchText) ?? false
            let jobRoleMatch = record.jobRole?.localizedCaseInsensitiveContains(searchText) ?? false
            let divisionMatch = record.division?.localizedCaseInsensitiveContains(searchText) ?? false
            let leaveDateMatch = record.leaveDate.map { DateFormatter.hrDateFormatter.string(from: $0).localizedCaseInsensitiveContains(searchText) } ?? false
            
            return systemAccountMatch || departmentMatch || departmentSimpleMatch || jobRoleMatch || divisionMatch || leaveDateMatch
        }
    }
    
    var filteredValidPackageRecords: [PackageStatusData] {
        filterRecords(validPackageRecords) { record in
            let applicationNameMatch = record.applicationName.localizedCaseInsensitiveContains(searchText)
            let packageStatusMatch = record.packageStatus.localizedCaseInsensitiveContains(searchText)
            let readinessDateMatch = record.packageReadinessDate.map { DateFormatter.hrDateFormatter.string(from: $0).localizedCaseInsensitiveContains(searchText) } ?? false
            let importDateMatch = DateFormatter.hrDateFormatter.string(from: record.importDate).localizedCaseInsensitiveContains(searchText)
            let importSetMatch = record.importSet.localizedCaseInsensitiveContains(searchText)
            
            return applicationNameMatch || packageStatusMatch || readinessDateMatch || importDateMatch || importSetMatch
        }
    }
    
    var filteredValidTestRecords: [TestingData] {
        filterRecords(validTestRecords) { record in
            let applicationNameMatch = record.applicationName.localizedCaseInsensitiveContains(searchText)
            let testStatusMatch = record.testStatus.localizedCaseInsensitiveContains(searchText)
            let testResultMatch = record.testResult.localizedCaseInsensitiveContains(searchText)
            let testDateMatch = record.testDate.map { DateFormatter.hrDateFormatter.string(from: $0).localizedCaseInsensitiveContains(searchText) } ?? false
            let planDateMatch = record.testingPlanDate.map { DateFormatter.hrDateFormatter.string(from: $0).localizedCaseInsensitiveContains(searchText) } ?? false
            
            return applicationNameMatch || testStatusMatch || testResultMatch || testDateMatch || planDateMatch
        }
    }
    
    var filteredValidMigrationRecords: [MigrationData] {
        filterRecords(validMigrationRecords) { record in
            let appNameMatch = record.applicationName.localizedCaseInsensitiveContains(searchText)
            let appNewMatch = record.applicationNew.localizedCaseInsensitiveContains(searchText)
            let appSuiteNewMatch = record.applicationSuiteNew.localizedCaseInsensitiveContains(searchText)
            let willBeMatch = record.willBe.localizedCaseInsensitiveContains(searchText)
            let scopeMatch = record.inScopeOutScopeDivision.localizedCaseInsensitiveContains(searchText)
            let platformMatch = record.migrationPlatform.localizedCaseInsensitiveContains(searchText)
            let readinessMatch = record.migrationApplicationReadiness.localizedCaseInsensitiveContains(searchText)
            
            return appNameMatch || appNewMatch || appSuiteNewMatch || willBeMatch || scopeMatch || platformMatch || readinessMatch
        }
    }
    
    var filteredValidClusterRecords: [ClusterData] {
        filterRecords(validClusterRecords) { record in
            let departmentMatch = record.department.localizedCaseInsensitiveContains(searchText)
            let departmentSimpleMatch = record.departmentSimple.localizedCaseInsensitiveContains(searchText)
            let domainMatch = record.domain.localizedCaseInsensitiveContains(searchText)
            let migrationClusterMatch = record.migrationCluster.localizedCaseInsensitiveContains(searchText)
            let readinessMatch = record.migrationClusterReadiness.localizedCaseInsensitiveContains(searchText)
            
            return departmentMatch || departmentSimpleMatch || domainMatch || migrationClusterMatch || readinessMatch
        }
    }
    
    var filteredInvalidRecords: [String] {
        filterRecords(invalidRecords) { $0.localizedCaseInsensitiveContains(searchText) }
    }
    
    var filteredDuplicateRecords: [String] {
        filterRecords(duplicateRecords) { $0.localizedCaseInsensitiveContains(searchText) }
    }
    
    // MARK: - Helper Methods
    
    private func filterRecords<T>(_ records: [T], matching predicate: (T) -> Bool) -> [T] {
        if searchText.isEmpty {
            return records
        }
        return records.filter(predicate)
    }
    
    func reset() {
        isProcessing = false
        progressValue = 0.0
        currentOperation = ""
        searchText = ""
        validRecords = []
        invalidRecords = []
        duplicateRecords = []
        validHRRecords = []
        invalidHRRecords = []
        duplicateHRRecords = []
        validPackageRecords = []
        invalidPackageRecords = []
        duplicatePackageRecords = []
        validTestRecords = []
        invalidTestRecords = []
        duplicateTestRecords = []
        validMigrationRecords = []
        invalidMigrationRecords = []
        duplicateMigrationRecords = []
        validClusterRecords = []
        invalidClusterRecords = []
        duplicateClusterRecords = []
    }
    
    func update(operation: String, progress: Double) {
        currentOperation = operation
        progressValue = progress
    }
} 