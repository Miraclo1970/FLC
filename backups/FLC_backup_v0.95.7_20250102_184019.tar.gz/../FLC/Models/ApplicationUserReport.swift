import Foundation

struct ApplicationUserReport {
    struct ApplicationInfo: Identifiable {
        let id = UUID()
        let name: String
        let users: Set<String>
        let division: String?
        let departmentSimple: String?
        let otap: String
    }
    
    let applications: [ApplicationInfo]
    let uniqueUsers: Set<String>
    
    init(from matrixData: [DatabaseManager.ApplicationUserMatrix]) {
        // Group by application
        let groupedByApp = Dictionary(grouping: matrixData) { $0.applicationName }
        
        // Create ApplicationInfo array
        self.applications = groupedByApp.map { appName, records in
            ApplicationInfo(
                name: appName,
                users: Set(records.map { $0.systemAccount }),
                division: records.first?.division,
                departmentSimple: records.first?.departmentSimple,
                otap: records.first?.otap ?? ""
            )
        }.sorted { $0.name < $1.name }
        
        // Get unique users
        self.uniqueUsers = Set(matrixData.map { $0.systemAccount })
    }
    
    // Helper methods
    func hasUser(_ application: String, user: String) -> Bool {
        guard let app = applications.first(where: { $0.name == application }) else {
            return false
        }
        return app.users.contains(user)
    }
    
    var totalApplications: Int {
        applications.count
    }
    
    var totalUsers: Int {
        uniqueUsers.count
    }
    
    var sortedUsers: [String] {
        Array(uniqueUsers).sorted()
    }
} 