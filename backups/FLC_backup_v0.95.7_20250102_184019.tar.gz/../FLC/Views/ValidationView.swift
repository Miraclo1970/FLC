import SwiftUI
import UniformTypeIdentifiers

struct ValidHRRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                VStack(spacing: 0) {
                    // Header
                    HStack(spacing: 0) {
                        Text("#")
                            .frame(width: 50, alignment: .leading)
                            .padding(.leading, 25)
                        Text("System Account")
                            .frame(width: 200, alignment: .leading)
                        Text("Department")
                            .frame(width: 200, alignment: .leading)
                        Text("Department Simple")
                            .frame(width: 150, alignment: .leading)
                        Text("Job Role")
                            .frame(width: 200, alignment: .leading)
                        Text("Division")
                            .frame(width: 200, alignment: .leading)
                        Text("Leave Date")
                            .frame(width: 120, alignment: .leading)
                    }
                    .padding(.vertical, 8)
                    .background(Color(NSColor.separatorColor).opacity(0.2))
                    .font(.headline)
                    
                    // Records
                    List {
                        ForEach(Array(progress.filteredValidHRRecords.enumerated()), id: \.1.systemAccount) { index, record in
                            HStack(spacing: 0) {
                                Text("#\(index + 1)")
                                    .frame(width: 50, alignment: .leading)
                                    .padding(.leading, 10)
                                    .foregroundColor(.secondary)
                                Text(record.systemAccount)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.department ?? "N/A")
                                    .frame(width: 200, alignment: .leading)
                                Text(record.departmentSimple ?? "N/A")
                                    .frame(width: 150, alignment: .leading)
                                Text(record.jobRole ?? "N/A")
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.division ?? "N/A")
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.leaveDate.map { DateFormatter.hrDateFormatter.string(from: $0) } ?? "N/A")
                                    .frame(width: 120, alignment: .leading)
                                    .lineLimit(1)
                                Spacer()
                            }
                            .font(.system(.body, design: .monospaced))
                        }
                    }
                }
            }
        }
    }
}

struct ValidRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                VStack(spacing: 0) {
                    // Header
                    HStack(spacing: 0) {
                        Text("#")
                            .frame(width: 50, alignment: .leading)
                            .padding(.leading, 25)
                        Text("AD Group")
                            .frame(width: 300, alignment: .leading)
                        Text("System Account")
                            .frame(width: 200, alignment: .leading)
                        Text("Application")
                            .frame(width: 250, alignment: .leading)
                        Text("Suite")
                            .frame(width: 200, alignment: .leading)
                        Text("OTAP")
                            .frame(width: 80, alignment: .leading)
                        Text("Critical")
                            .frame(width: 80, alignment: .leading)
                        Spacer()
                    }
                    .padding(.vertical, 8)
                    .background(Color(NSColor.separatorColor).opacity(0.2))
                    .font(.headline)
                    
                    // Records
                    List {
                        ForEach(Array(progress.filteredValidRecords.enumerated()), id: \.element.id) { index, record in
                            if index > 0 {  // Skip the first row (header)
                                HStack(spacing: 0) {
                                    Text("#\(index)")
                                        .frame(width: 50, alignment: .leading)
                                        .padding(.leading, 10)
                                        .foregroundColor(.secondary)
                                    Text(record.adGroup)
                                        .frame(width: 300, alignment: .leading)
                                        .lineLimit(1)
                                    Text(record.systemAccount)
                                        .frame(width: 200, alignment: .leading)
                                        .lineLimit(1)
                                    Text(record.applicationName)
                                        .frame(width: 250, alignment: .leading)
                                        .lineLimit(1)
                                    Text(record.applicationSuite)
                                        .frame(width: 200, alignment: .leading)
                                        .lineLimit(1)
                                    Text(record.otap)
                                        .frame(width: 80, alignment: .leading)
                                        .lineLimit(1)
                                    Text(record.critical)
                                        .frame(width: 80, alignment: .leading)
                                        .lineLimit(1)
                                    Spacer()
                                }
                                .font(.system(.body, design: .monospaced))
                            }
                        }
                    }
                }
            }
        }
    }
}

struct ValidPackageStatusRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    var body: some View {
        VStack(spacing: 0) {
            if progress.validPackageRecords.isEmpty {
                Text("No package status records available")
                    .foregroundColor(.secondary)
                    .padding()
            } else {
                ScrollView {
                    ForEach(Array(progress.filteredValidPackageRecords.enumerated()), id: \.1.applicationName) { index, record in
                        HStack(spacing: 0) {
                            Text("#\(index + 1)")
                                .frame(width: 50, alignment: .leading)
                                .padding(.leading, 10)
                                .foregroundColor(.secondary)
                            Text(record.applicationName)
                                .frame(width: 250, alignment: .leading)
                            Text(record.packageStatus)
                                .frame(width: 150, alignment: .leading)
                            Text(record.packageReadinessDate.map { DateFormatter.hrDateFormatter.string(from: $0) } ?? "N/A")
                                .frame(width: 150, alignment: .leading)
                            Text(DateFormatter.hrDateFormatter.string(from: record.importDate))
                                .frame(width: 150, alignment: .leading)
                            Text(record.importSet)
                                .frame(width: 200, alignment: .leading)
                        }
                        .font(.system(.body, design: .monospaced))
                        .padding(.vertical, 4)
                        .background(index % 2 == 0 ? Color.clear : Color(NSColor.separatorColor).opacity(0.05))
                    }
                }
            }
        }
    }
}

struct ValidTestRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    private var headerView: some View {
        HStack(spacing: 0) {
            Text("#")
                .frame(width: 50, alignment: .leading)
                .padding(.leading, 25)
            Text("Application Name")
                .frame(width: 200, alignment: .leading)
            Text("Test Status")
                .frame(width: 150, alignment: .leading)
            Text("Test Readiness Date")
                .frame(width: 150, alignment: .leading)
            Text("Test Result")
                .frame(width: 150, alignment: .leading)
            Text("Testing Plan Date")
                .frame(width: 200, alignment: .leading)
        }
        .padding(.vertical, 8)
        .background(Color(NSColor.separatorColor).opacity(0.2))
        .font(.headline)
    }
    
    private func recordRow(index: Int, record: TestingData) -> some View {
        HStack(spacing: 0) {
            Text("#\(index + 1)")
                .frame(width: 50, alignment: .leading)
                .padding(.leading, 25)
            Text(record.applicationName)
                .frame(width: 200, alignment: .leading)
                .lineLimit(1)
            Text(record.testStatus)
                .frame(width: 150, alignment: .leading)
                .lineLimit(1)
            Text(record.testDate.map { DateFormatter.hrDateFormatter.string(from: $0) } ?? "N/A")
                .frame(width: 150, alignment: .leading)
                .lineLimit(1)
            Text(record.testResult)
                .frame(width: 150, alignment: .leading)
                .lineLimit(1)
            Text(record.testingPlanDate.map { DateFormatter.hrDateFormatter.string(from: $0) } ?? "N/A")
                .frame(width: 200, alignment: .leading)
                .lineLimit(1)
        }
        .font(.system(.body, design: .monospaced))
    }
    
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                VStack(spacing: 0) {
                    headerView
                    
                    List {
                        ForEach(Array(progress.filteredValidTestRecords.enumerated()), id: \.1.id) { index, record in
                            recordRow(index: index, record: record)
                        }
                    }
                }
            }
        }
    }
}

struct ValidMigrationRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                VStack(spacing: 0) {
                    // Header
                    HStack(spacing: 0) {
                        Text("#")
                            .frame(width: 50, alignment: .leading)
                            .padding(.leading, 25)
                        Text("Application Name")
                            .frame(width: 200, alignment: .leading)
                        Text("Application New")
                            .frame(width: 200, alignment: .leading)
                        Text("Application Suite New")
                            .frame(width: 200, alignment: .leading)
                        Text("Will Be")
                            .frame(width: 150, alignment: .leading)
                        Text("In/Out Scope Division")
                            .frame(width: 200, alignment: .leading)
                        Text("Migration Platform")
                            .frame(width: 200, alignment: .leading)
                        Text("Application Readiness")
                            .frame(width: 200, alignment: .leading)
                    }
                    .padding(.vertical, 8)
                    .background(Color(NSColor.separatorColor).opacity(0.2))
                    .font(.headline)
                    
                    // Records
                    List {
                        ForEach(Array(progress.filteredValidMigrationRecords.enumerated()), id: \.element.id) { index, record in
                            HStack(spacing: 0) {
                                Text("#\(index + 1)")
                                    .frame(width: 50, alignment: .leading)
                                    .padding(.leading, 10)
                                    .foregroundColor(.secondary)
                                Text(record.applicationName)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.applicationNew)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.applicationSuiteNew)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.willBe)
                                    .frame(width: 150, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.inScopeOutScopeDivision)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.migrationPlatform)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Text(record.migrationApplicationReadiness)
                                    .frame(width: 200, alignment: .leading)
                                    .lineLimit(1)
                                Spacer()
                            }
                            .font(.system(.body, design: .monospaced))
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

struct ValidClusterRecordsView: View {
    @ObservedObject var progress: ImportProgress
    
    private func migrationClusterReadinessDisplay(_ status: String) -> (text: String, color: Color) {
        switch status {
        case "N/A", "":
            return ("Not started", Color.gray)
        case "Preparation":
            return ("Preparation", Color.blue.opacity(0.3))
        case "Planned":
            return ("Planned", Color.blue.opacity(0.6))
        case "Done":
            return ("Done", Color.blue.opacity(0.9))
        case "Aftercare":
            return ("Aftercare", Color.green.opacity(0.3))
        case "Decharge":
            return ("Decharge", Color.green.opacity(0.6))
        default:
            return (status, Color.primary)
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 0) {
                Text("Department")
                    .frame(width: 200, alignment: .leading)
                Text("Department Simple")
                    .frame(width: 200, alignment: .leading)
                Text("Domain")
                    .frame(width: 150, alignment: .leading)
                Text("Migration Cluster")
                    .frame(width: 200, alignment: .leading)
                Text("Migration Cluster Readiness")
                    .frame(width: 200, alignment: .leading)
            }
            .padding(.vertical, 4)
            .font(.system(size: 11, weight: .bold))
            .background(Color(NSColor.windowBackgroundColor))
            
            // Results
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(progress.filteredValidClusterRecords) { record in
                        HStack(spacing: 0) {
                            Text(record.department)
                                .frame(width: 200, alignment: .leading)
                            Text(record.departmentSimple)
                                .frame(width: 200, alignment: .leading)
                            Text(record.domain)
                                .frame(width: 150, alignment: .leading)
                            Text(record.migrationCluster)
                                .frame(width: 200, alignment: .leading)
                            let display = migrationClusterReadinessDisplay(record.migrationClusterReadiness)
                            Text(display.text)
                                .frame(width: 200, alignment: .leading)
                                .foregroundColor(display.color)
                        }
                        .frame(height: 18)
                        .font(.system(size: 11))
                        .background(progress.filteredValidClusterRecords.firstIndex(where: { $0.id == record.id })!.isMultiple(of: 2) ? Color(NSColor.controlBackgroundColor) : Color.clear)
                    }
                }
            }
        }
    }
}

struct ValidationView: View {
    @State private var selectedTab = 0
    @ObservedObject var progress: ImportProgress
    @State private var isSaving = false
    @State private var saveResult: String?
    @State private var saveProgress: Double = 0.0
    private let batchSize = 5000
    
    private var stats: [(String, String)] {
        let counts = calculateStats(for: progress.selectedDataType)
        return [
            ("Total Records", "\(counts.total)"),
            ("Valid Records", "\(counts.valid)"),
            ("Invalid Records", "\(counts.invalid)"),
            ("Duplicate Records", "\(counts.duplicates)")
        ]
    }
    
    private func calculateStats(for dataType: ImportProgress.DataType) -> (total: Int, valid: Int, invalid: Int, duplicates: Int) {
        switch dataType {
        case .ad:
            let validCount = progress.validRecords.count
            let invalidCount = progress.invalidRecords.count
            let duplicateCount = progress.duplicateRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .hr:
            let validCount = progress.validHRRecords.count
            let invalidCount = progress.invalidHRRecords.count
            let duplicateCount = progress.duplicateHRRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .packageStatus:
            let validCount = progress.validPackageRecords.count
            let invalidCount = progress.invalidPackageRecords.count
            let duplicateCount = progress.duplicatePackageRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .testing:
            let validCount = progress.validTestRecords.count
            let invalidCount = progress.invalidTestRecords.count
            let duplicateCount = progress.duplicateTestRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .migration:
            let validCount = progress.validMigrationRecords.count
            let invalidCount = progress.invalidMigrationRecords.count
            let duplicateCount = progress.duplicateMigrationRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .cluster:
            let validCount = progress.validClusterRecords.count
            let invalidCount = progress.invalidClusterRecords.count
            let duplicateCount = progress.duplicateClusterRecords.count
            let totalCount = validCount + invalidCount + duplicateCount
            return (totalCount, validCount, invalidCount, duplicateCount)
            
        case .combined:
            return (0, 0, 0, 0)  // Combined view doesn't have its own records
        }
    }
    
    var body: some View {
        VStack(spacing: 20) {
            // Data Type Picker with enhanced visibility
            VStack(spacing: 8) {
                Text("Select Data Type")
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Picker("Data Type", selection: $progress.selectedDataType) {
                    Text("AD Data").tag(ImportProgress.DataType.ad)
                    Text("HR Data").tag(ImportProgress.DataType.hr)
                    Text("Package Status").tag(ImportProgress.DataType.packageStatus)
                    Text("Testing").tag(ImportProgress.DataType.testing)
                    Text("Migration").tag(ImportProgress.DataType.migration)
                    Text("Cluster").tag(ImportProgress.DataType.cluster)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(8)
                .onChange(of: progress.selectedDataType) { oldValue, newValue in
                    if newValue == .combined {
                        // If somehow combined is selected, switch back to AD
                        progress.selectedDataType = .ad
                    }
                }
            }
            .padding(.horizontal)
            
            // Stats Cards and Save Button
            HStack {
                // Stats Cards
                HStack(spacing: 20) {
                    ForEach(stats, id: \.0) { stat in
                        DashboardCard(
                            title: stat.0,
                            value: stat.1,
                            icon: iconForStat(stat.0)
                        )
                    }
                }
                
                Spacer()
                
                // Save Button and Download Button
                VStack(spacing: 10) {
                    if hasValidRecords {
                        VStack(spacing: 5) {
                            Button(action: saveToDatabase) {
                                if isSaving {
                                    ProgressView()
                                        .controlSize(.small)
                                        .scaleEffect(0.7)
                                } else {
                                    Text("Save Valid Records to Database")
                                }
                            }
                            .disabled(isSaving)
                            .buttonStyle(.borderedProminent)
                            
                            if isSaving {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Saving...")
                                        .foregroundColor(.secondary)
                                    ProgressView()
                                }
                            }
                        }
                    }
                    
                    if hasInvalidOrDuplicateRecords {
                        Button(action: downloadInvalidAndDuplicates) {
                            Text("Download Invalid and Duplicates")
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }
            .padding()
            
            // Save Result Message
            if let result = saveResult {
                Text(result)
                    .foregroundColor(result.contains("Error") ? .red : .green)
                    .padding(.horizontal)
            }
            
            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Search in validation results...", text: $progress.searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                if !progress.searchText.isEmpty {
                    Button(action: { progress.searchText = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.horizontal)
            
            // Tabs and Content
            TabView(selection: $selectedTab) {
                // Valid Records Tab
                Group {
                    switch progress.selectedDataType {
                    case .ad:
                        ValidRecordsView(progress: progress)
                    case .hr:
                        ValidHRRecordsView(progress: progress)
                    case .packageStatus:
                        ValidPackageStatusRecordsView(progress: progress)
                    case .testing:
                        ValidTestRecordsView(progress: progress)
                    case .migration:
                        ValidMigrationRecordsView(progress: progress)
                    case .cluster:
                        ValidClusterRecordsView(progress: progress)
                    case .combined:
                        Text("Combined records cannot be validated")
                    }
                }
                .tabItem {
                    Label("Valid", systemImage: "checkmark.circle")
                }
                .tag(0)
                
                // Invalid Records Tab
                Group {
                    switch progress.selectedDataType {
                    case .ad:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    case .hr:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    case .packageStatus:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    case .testing:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    case .migration:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    case .cluster:
                        InvalidRecordsView(records: progress.filteredInvalidRecords, searchText: progress.searchText)
                    default:
                        Text("No invalid records to display")
                    }
                }
                .tabItem {
                    Label("Invalid", systemImage: "xmark.circle")
                }
                .tag(1)
                
                // Duplicate Records Tab
                Group {
                    switch progress.selectedDataType {
                    case .ad:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    case .hr:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    case .packageStatus:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    case .testing:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    case .migration:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    case .cluster:
                        DuplicateRecordsView(records: progress.filteredDuplicateRecords, searchText: progress.searchText)
                    default:
                        Text("No duplicate records to display")
                    }
                }
                .tabItem {
                    Label("Duplicates", systemImage: "doc.on.doc")
                }
                .tag(2)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(NSColor.windowBackgroundColor))
        // Reset to valid records tab when switching data types
        .onChange(of: progress.selectedDataType) { oldValue, newValue in
            selectedTab = 0
        }
    }
    
    private func iconForStat(_ stat: String) -> String {
        switch stat {
        case "Total Records":
            return "doc.text"
        case "Valid Records":
            return "checkmark.circle"
        case "Invalid Records":
            return "xmark.circle"
        case "Duplicate Records":
            return "doc.on.doc"
        default:
            return "doc"
        }
    }
}

struct InvalidRecordsView: View {
    let records: [String]
    let searchText: String
    
    var filteredRecords: [String] {
        if searchText.isEmpty {
            return records
        }
        return records.filter { $0.localizedCaseInsensitiveContains(searchText) }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 0) {
                Text("#")
                    .frame(width: 40, alignment: .leading)
                Text("Error Message")
                    .frame(maxWidth: .infinity, alignment: .leading)
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 8)
            .background(Color(NSColor.separatorColor).opacity(0.2))
            .font(.headline)
            
            if records.isEmpty {
                Text("No invalid records found")
                    .foregroundColor(.secondary)
                    .padding()
            } else {
                // Records
                List {
                    ForEach(Array(filteredRecords.enumerated()), id: \.element) { index, record in
                        HStack(spacing: 0) {
                            Text("#\(index + 1)")
                                .frame(width: 40, alignment: .leading)
                                .foregroundColor(.secondary)
                            Text(record)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundColor(.red)
                                .lineLimit(nil) // Allow multiple lines
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 4)
                        .font(.system(.body, design: .monospaced))
                    }
                }
            }
        }
    }
}

struct DuplicateRecordsView: View {
    let records: [String]
    let searchText: String
    
    var filteredRecords: [String] {
        if searchText.isEmpty {
            return records
        }
        return records.filter { $0.localizedCaseInsensitiveContains(searchText) }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 0) {
                Text("#")
                    .frame(width: 40, alignment: .leading)
                Text("Duplicate Information")
                    .frame(maxWidth: .infinity, alignment: .leading)
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 8)
            .background(Color(NSColor.separatorColor).opacity(0.2))
            .font(.headline)
            
            // Records
            List {
                ForEach(Array(filteredRecords.enumerated()), id: \.element) { index, record in
                    HStack(spacing: 0) {
                        Text("#\(index + 1)")
                            .frame(width: 40, alignment: .leading)
                            .foregroundColor(.secondary)
                        Text(record)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .foregroundColor(.orange)
                            .lineLimit(1)
                    }
                    .padding(.horizontal, 20)
                    .font(.system(.body, design: .monospaced))
                }
            }
        }
    }
}

extension ValidationView {
    private var hasValidRecords: Bool {
        switch progress.selectedDataType {
        case .ad:
            return !progress.validRecords.isEmpty
        case .hr:
            return !progress.validHRRecords.isEmpty
        case .packageStatus:
            return !progress.validPackageRecords.isEmpty
        case .testing:
            return !progress.validTestRecords.isEmpty
        case .migration:
            return !progress.validMigrationRecords.isEmpty
        case .cluster:
            return !progress.validClusterRecords.isEmpty
        case .combined:
            return false  // Combined view doesn't have its own records
        }
    }
    
    private var hasInvalidOrDuplicateRecords: Bool {
        switch progress.selectedDataType {
        case .ad:
            return !progress.invalidRecords.isEmpty ||
                   !progress.duplicateRecords.isEmpty
        case .hr:
            return !progress.invalidHRRecords.isEmpty ||
                   !progress.duplicateHRRecords.isEmpty
        case .packageStatus:
            return !progress.invalidPackageRecords.isEmpty ||
                   !progress.duplicatePackageRecords.isEmpty
        case .testing:
            return !progress.invalidTestRecords.isEmpty ||
                   !progress.duplicateTestRecords.isEmpty
        case .migration:
            return !progress.invalidMigrationRecords.isEmpty ||
                   !progress.duplicateMigrationRecords.isEmpty
        case .cluster:
            return !progress.invalidClusterRecords.isEmpty ||
                   !progress.duplicateClusterRecords.isEmpty
        case .combined:
            return false  // Combined view doesn't have its own records
        }
    }
    
    private func downloadInvalidAndDuplicates() {
        Task { @MainActor in
            let savePanel = NSSavePanel()
            savePanel.allowedContentTypes = [UTType.commaSeparatedText]
            savePanel.nameFieldStringValue = "invalid_and_duplicates.csv"
            savePanel.canCreateDirectories = true
            
            let response = await savePanel.begin()
            
            if response == .OK, let url = savePanel.url {
                var csvContent = "Type,Record\n"  // Simplified header
                
                // Add invalid records
                let invalidRecords = progress.selectedDataType == .ad ? progress.invalidRecords : progress.invalidHRRecords
                for record in invalidRecords {
                    let escapedRecord = record.replacingOccurrences(of: "\"", with: "\"\"")
                    csvContent += "Invalid,\"\(escapedRecord)\"\n"
                }
                
                // Add duplicate records
                let duplicateRecords = progress.selectedDataType == .ad ? progress.duplicateRecords : progress.duplicateHRRecords
                for record in duplicateRecords {
                    let escapedRecord = record.replacingOccurrences(of: "\"", with: "\"\"")
                    csvContent += "Duplicate,\"\(escapedRecord)\"\n"
                }
                
                do {
                    try csvContent.write(to: url, atomically: true, encoding: .utf8)
                    saveResult = "Successfully downloaded invalid and duplicate records to CSV file."
                } catch {
                    saveResult = "Error saving CSV file: \(error.localizedDescription)"
                }
            }
        }
    }
    
    private func saveToDatabase() {
        isSaving = true
        saveProgress = 0.0
        saveResult = nil
        
        Task {
            do {
                switch progress.selectedDataType {
                case .ad:
                    let records = progress.validRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.saveADRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                    
                case .hr:
                    let records = progress.validHRRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.saveHRRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                case .packageStatus:
                    let records = progress.validPackageRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.savePackageRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                case .testing:
                    let records = progress.validTestRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.saveTestRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                case .migration:
                    let records = progress.validMigrationRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.saveMigrationRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                case .cluster:
                    let records = progress.validClusterRecords
                    var totalSaved = 0
                    var totalSkipped = 0
                    let totalBatches = Int(ceil(Double(records.count) / Double(batchSize)))
                    
                    for batchIndex in 0..<totalBatches {
                        let start = batchIndex * batchSize
                        let end = min(start + batchSize, records.count)
                        let batch = Array(records[start..<end])
                        
                        let (saved, skipped) = try await DatabaseManager.shared.saveClusterRecords(batch)
                        totalSaved += saved
                        totalSkipped += skipped
                        
                        await MainActor.run {
                            saveProgress = Double(end) / Double(records.count)
                            saveResult = "Processing: \(end)/\(records.count) records..."
                        }
                    }
                    
                    await MainActor.run {
                        saveProgress = 1.0
                        saveResult = "Successfully saved \(totalSaved) records to database. \(totalSkipped) records skipped (duplicates)."
                    }
                case .combined:
                    break  // Combined view doesn't have its own records to save
                }
            } catch {
                await MainActor.run {
                    saveProgress = 0.0
                    saveResult = "Error saving to database: \(error.localizedDescription)"
                }
            }
            
            await MainActor.run {
                isSaving = false
            }
        }
    }
}

struct VisualEffectView: NSViewRepresentable {
    let material: NSVisualEffectView.Material
    let blendingMode: NSVisualEffectView.BlendingMode
    
    func makeNSView(context: Context) -> NSVisualEffectView {
        let visualEffectView = NSVisualEffectView()
        visualEffectView.material = material
        visualEffectView.blendingMode = blendingMode
        visualEffectView.state = .active
        return visualEffectView
    }
    
    func updateNSView(_ visualEffectView: NSVisualEffectView, context: Context) {
        visualEffectView.material = material
        visualEffectView.blendingMode = blendingMode
    }
}

#Preview {
    ValidationView(progress: ImportProgress())
} 