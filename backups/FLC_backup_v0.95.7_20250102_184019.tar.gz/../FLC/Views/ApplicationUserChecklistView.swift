import SwiftUI
import GRDB

struct ApplicationUserChecklistView: View {
    @EnvironmentObject private var databaseManager: DatabaseManager
    @State private var report: ApplicationUserReport?
    @State private var isLoading = false
    @State private var isGeneratingMatrix = false
    @State private var searchText = ""
    @State private var selectedEnvironments: Set<String> = ["P"]  // Default to Production
    @State private var selectedDivision = ""
    @State private var selectedDepartments: Set<String> = []  // Changed to Set for multiple selection
    @State private var divisions: [String] = []
    @State private var departments: [String] = []
    @State private var showPivotTable = false
    
    private let environments = ["P", "A", "T"]
    
    // Filtered applications and users based on search text
    private var filteredApplications: [ApplicationUserReport.ApplicationInfo] {
        guard let report = report else { return [] }
        if searchText.isEmpty {
            return report.applications
        }
        return report.applications
            .filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }
    
    private var filteredUsers: [String] {
        guard let report = report else { return [] }
        if searchText.isEmpty {
            return report.sortedUsers
        }
        return report.sortedUsers
            .filter { $0.localizedCaseInsensitiveContains(searchText) }
    }
    
    var body: some View {
        VStack(spacing: 20) {
            // Selection Section
            VStack(alignment: .leading, spacing: 12) {
                // Division Selection
                VStack(alignment: .leading) {
                    Text("1. Select Division:")
                        .font(.headline)
                    HStack(spacing: 20) {
                        Picker("", selection: $selectedDivision) {
                            Text("Select Division").tag("")
                            ForEach(divisions, id: \.self) { division in
                                Text(division).tag(division)
                            }
                        }
                        .frame(width: 200)
                        .onChange(of: selectedDivision) {
                            selectedDepartments.removeAll()  // Clear selected departments
                            showPivotTable = false
                            report = nil
                            if !selectedDivision.isEmpty {
                                Task {
                                    await loadDepartments()
                                }
                            }
                        }
                        .disabled(isLoading || isGeneratingMatrix)
                        
                        // Environment Filter
                        environmentFilters
                    }
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(10)
                
                // Department Selection (only if division is selected)
                if !selectedDivision.isEmpty {
                    VStack(alignment: .leading) {
                        Text("2. Select Departments:")
                            .font(.headline)
                        
                        ScrollView {
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(departments.sorted(), id: \.self) { department in
                                    Toggle(department, isOn: Binding(
                                        get: { selectedDepartments.contains(department) },
                                        set: { isSelected in
                                            if isSelected {
                                                selectedDepartments.insert(department)
                                            } else {
                                                selectedDepartments.remove(department)
                                            }
                                            showPivotTable = false
                                            report = nil
                                        }
                                    ))
                                    .toggleStyle(.checkbox)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                        .frame(maxHeight: 200)  // Limit the height and make it scrollable
                    }
                    .padding()
                    .background(Color(NSColor.controlBackgroundColor))
                    .cornerRadius(10)
                }
                
                // Generate Button
                if !selectedDivision.isEmpty && !selectedDepartments.isEmpty {
                    Button(action: {
                        Task {
                            await generateMatrix()
                        }
                    }) {
                        if isGeneratingMatrix {
                            ProgressView()
                                .scaleEffect(0.5)
                        } else {
                            Text("3. Generate Matrix")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isLoading || isGeneratingMatrix)
                }
            }
            
            // Loading indicator for initial data load
            if isLoading {
                ProgressView("Loading data...")
                    .scaleEffect(0.8)
            }
            
            // Pivot Table
            if showPivotTable {
                pivotTableView
            }
        }
        .padding()
        .task {
            await initialLoad()
        }
    }
    
    private func initialLoad() async {
        guard !isLoading else { return }
        isLoading = true
        defer { isLoading = false }
        
        await loadDivisions()
    }
    
    private func generateMatrix() async {
        guard !isGeneratingMatrix else { return }
        isGeneratingMatrix = true
        defer { isGeneratingMatrix = false }
        
        await loadPivotData()
    }
    
    private var environmentFilters: some View {
        HStack(spacing: 8) {
            Text("Environment:")
                .font(.subheadline)
            ForEach(environments, id: \.self) { env in
                Toggle(env, isOn: Binding(
                    get: { selectedEnvironments.contains(env) },
                    set: { isSelected in
                        if isSelected {
                            selectedEnvironments.insert(env)
                        } else if selectedEnvironments.count > 1 {
                            selectedEnvironments.remove(env)
                        }
                        // Reset view state but don't regenerate matrix
                        showPivotTable = false
                        report = nil
                        selectedDepartments.removeAll()
                        
                        // Reload divisions
                        Task {
                            await loadDivisions()
                        }
                    }
                ))
                .toggleStyle(.checkbox)
            }
        }
    }
    
    private var pivotTableView: some View {
        VStack {
            // Search field
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search users or applications", text: $searchText)
            }
            .padding(8)
            .background(Color(NSColor.controlBackgroundColor))
            .cornerRadius(8)
            .frame(maxWidth: 250)
            
            // Stats
            HStack {
                Text("Applications: \(filteredApplications.count)")
                Text("Users: \(filteredUsers.count)")
            }
            .font(.caption)
            .foregroundColor(.gray)
            
            // Pivot Table
            ScrollView([.horizontal, .vertical]) {
                VStack(alignment: .leading, spacing: 0) {
                    // Header row with user names
                    HStack(spacing: 0) {
                        // Empty cell for top-left corner
                        Text("Application")
                            .frame(width: 250, alignment: .leading)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.gray.opacity(0.2))
                            .border(Color.gray.opacity(0.2), width: 1)
                        
                        // User columns
                        ForEach(filteredUsers, id: \.self) { user in
                            Text(user)
                                .frame(width: 100)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.2))
                                .border(Color.gray.opacity(0.2), width: 1)
                                .rotationEffect(.degrees(-45))
                                .frame(height: 100)
                        }
                    }
                    
                    // Application rows
                    ForEach(filteredApplications) { app in
                        HStack(spacing: 0) {
                            // Application name
                            Text(app.name)
                                .frame(width: 250, alignment: .leading)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color(NSColor.controlBackgroundColor))
                                .border(Color.gray.opacity(0.2), width: 1)
                            
                            // User checkmarks
                            ForEach(filteredUsers, id: \.self) { user in
                                Text(app.users.contains(user) ? "✓" : "")
                                    .frame(width: 100)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(Color(NSColor.controlBackgroundColor))
                                    .border(Color.gray.opacity(0.2), width: 1)
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func loadDivisions() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            divisions = try await databaseManager.getUniqueDivisions(environments: selectedEnvironments)
        } catch {
            print("Error loading divisions: \(error)")
        }
    }
    
    private func loadDepartments() async {
        guard !selectedDivision.isEmpty else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            departments = try await databaseManager.getUniqueDepartments(
                division: selectedDivision,
                environments: selectedEnvironments
            )
        } catch {
            print("Error loading departments: \(error)")
        }
    }
    
    private func loadPivotData() async {
        do {
            var allMatrixData: [DatabaseManager.ApplicationUserMatrix] = []
            
            // Fetch data for each selected department
            for department in selectedDepartments {
                let matrixData = try await databaseManager.fetchApplicationUserMatrix(
                    division: selectedDivision.isEmpty ? nil : selectedDivision,
                    department: department,
                    environments: selectedEnvironments
                )
                allMatrixData.append(contentsOf: matrixData)
            }
            
            report = ApplicationUserReport(from: allMatrixData)
            showPivotTable = true
        } catch {
            print("Error loading pivot data: \(error)")
        }
    }
}

#Preview {
    ApplicationUserChecklistView()
        .environmentObject(DatabaseManager.shared)
} 